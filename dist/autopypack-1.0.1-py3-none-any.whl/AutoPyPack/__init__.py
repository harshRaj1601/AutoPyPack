from .AutoPyPack import _auto_scan
_auto_scan()  # Automatically scan the importing script for dependencies